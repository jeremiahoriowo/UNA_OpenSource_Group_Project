
 {
function BxDolStudioLogin(){$(document).ready(function(){$('#bx-std-login-form-box').dolPopup({fog:{color:'#fff',opacity:0},closeOnOuterClick:!1})})}
 }
